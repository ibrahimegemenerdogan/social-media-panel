import React, { useState, useEffect, useCallback } from 'react';
import { Users, Heart, Share2, Wifi, WifiOff, Instagram, Youtube, Bell, Settings, LogOut, Upload } from 'lucide-react';
import { useDropzone } from 'react-dropzone';

// OAuth configuration
const YOUTUBE_CLIENT_ID = 'your_youtube_client_id';
const YOUTUBE_REDIRECT_URI = `${window.location.origin}/auth/youtube/callback`;
const INSTAGRAM_CLIENT_ID = 'your_instagram_client_id';
const INSTAGRAM_REDIRECT_URI = `${window.location.origin}/auth/instagram/callback`;

function App() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedPlatform, setSelectedPlatform] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [isUploading, setIsUploading] = useState(false);
  const [connectedAccounts, setConnectedAccounts] = useState<{
    youtube?: { connected: boolean; username?: string };
    instagram?: { connected: boolean; username?: string };
  }>({});

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Check for OAuth callbacks
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const state = params.get('state');

    if (code && state) {
      handleOAuthCallback(code, state);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleOAuthCallback = async (code: string, state: string) => {
    try {
      if (state === 'youtube') {
        // Exchange code for YouTube access token
        setConnectedAccounts(prev => ({
          ...prev,
          youtube: { connected: true, username: 'YouTube Channel' }
        }));
      } else if (state === 'instagram') {
        // Exchange code for Instagram access token
        setConnectedAccounts(prev => ({
          ...prev,
          instagram: { connected: true, username: '@instagram.user' }
        }));
      }
      
      // Remove query parameters from URL
      window.history.replaceState({}, document.title, window.location.pathname);
    } catch (error) {
      console.error('Error during OAuth callback:', error);
    }
  };

  const connectYouTube = () => {
    const scope = 'https://www.googleapis.com/auth/youtube.upload';
    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${YOUTUBE_CLIENT_ID}&redirect_uri=${YOUTUBE_REDIRECT_URI}&response_type=code&scope=${scope}&state=youtube`;
    window.location.href = authUrl;
  };

  const connectInstagram = () => {
    const scope = 'user_profile,user_media';
    const authUrl = `https://api.instagram.com/oauth/authorize?client_id=${INSTAGRAM_CLIENT_ID}&redirect_uri=${INSTAGRAM_REDIRECT_URI}&response_type=code&scope=${scope}&state=instagram`;
    window.location.href = authUrl;
  };

  const disconnectAccount = (platform: 'youtube' | 'instagram') => {
    setConnectedAccounts(prev => ({
      ...prev,
      [platform]: { connected: false }
    }));
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (!selectedPlatform || !isOnline) return;

    const file = acceptedFiles[0];
    if (!file) return;

    setIsUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          setSelectedPlatform(null);
          return 100;
        }
        return prev + 10;
      });
    }, 500);
  }, [selectedPlatform, isOnline]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'video/*': ['.mp4', '.mov', '.avi']
    },
    disabled: !selectedPlatform || !isOnline
  });

  const stats = [
    { icon: <Users className="w-6 h-6" />, value: '12.5K', label: 'Followers', color: '#3b82f6' },
    { icon: <Heart className="w-6 h-6" />, value: '8.2K', label: 'Likes', color: '#ef4444' },
    { icon: <Share2 className="w-6 h-6" />, value: '4.7K', label: 'Shares', color: '#10b981' }
  ];

  const activities = [
    { text: 'Posted a new YouTube video on digital marketing', time: '2 hours ago' },
    { text: 'Shared new Instagram Reel', time: '4 hours ago' },
    { text: 'Responded to Instagram comments', time: '6 hours ago' }
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-white shadow">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold text-gray-800">Content Creator Dashboard</h1>
          <div className="flex items-center gap-4">
            <div className={`flex items-center gap-2 text-sm ${isOnline ? 'text-green-600' : 'text-red-600'}`}>
              {isOnline ? (
                <>
                  <Wifi className="w-4 h-4" />
                  <span>Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-4 h-4" />
                  <span>Offline</span>
                </>
              )}
            </div>
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <Bell className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <Settings className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <LogOut className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex gap-4 mb-8">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-4 py-2 rounded-lg ${
              activeTab === 'dashboard' ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('accounts')}
            className={`px-4 py-2 rounded-lg ${
              activeTab === 'accounts' ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'
            }`}
          >
            Connected Accounts
          </button>
          <button
            onClick={() => setActiveTab('upload')}
            className={`px-4 py-2 rounded-lg ${
              activeTab === 'upload' ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'
            }`}
          >
            Upload Content
          </button>
        </div>

        {activeTab === 'dashboard' ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {stats.map((stat, index) => (
                <div 
                  key={index}
                  className="bg-white rounded-lg shadow-md p-6 flex items-center space-x-4"
                  style={{ borderLeft: `4px solid ${stat.color}` }}
                >
                  <div className="p-3 rounded-full" style={{ color: stat.color }}>
                    {stat.icon}
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{stat.value}</div>
                    <div className="text-gray-500">{stat.label}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4">Recent Activities</h2>
              <div className="space-y-4">
                {activities.map((activity, index) => (
                  <div key={index} className="border-b border-gray-100 last:border-0 pb-4 last:pb-0">
                    <p className="text-gray-800">{activity.text}</p>
                    <p className="text-sm text-gray-500 mt-1">{activity.time}</p>
                  </div>
                ))}
              </div>
            </div>
          </>
        ) : activeTab === 'accounts' ? (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-6">Connected Accounts</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                <div className="flex items-center gap-3">
                  <div className="text-red-600">
                    <Youtube className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-medium">YouTube</div>
                    {connectedAccounts.youtube?.connected ? (
                      <div className="text-sm text-gray-500">{connectedAccounts.youtube.username}</div>
                    ) : (
                      <div className="text-sm text-gray-500">Not connected</div>
                    )}
                  </div>
                </div>
                {connectedAccounts.youtube?.connected ? (
                  <button 
                    onClick={() => disconnectAccount('youtube')}
                    className="text-sm text-red-600 hover:text-red-700"
                  >
                    Disconnect
                  </button>
                ) : (
                  <button 
                    onClick={connectYouTube}
                    className="text-sm text-blue-600 hover:text-blue-700"
                  >
                    Connect
                  </button>
                )}
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                <div className="flex items-center gap-3">
                  <div className="text-pink-600">
                    <Instagram className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-medium">Instagram</div>
                    {connectedAccounts.instagram?.connected ? (
                      <div className="text-sm text-gray-500">{connectedAccounts.instagram.username}</div>
                    ) : (
                      <div className="text-sm text-gray-500">Not connected</div>
                    )}
                  </div>
                </div>
                {connectedAccounts.instagram?.connected ? (
                  <button 
                    onClick={() => disconnectAccount('instagram')}
                    className="text-sm text-red-600 hover:text-red-700"
                  >
                    Disconnect
                  </button>
                ) : (
                  <button 
                    onClick={connectInstagram}
                    className="text-sm text-blue-600 hover:text-blue-700"
                  >
                    Connect
                  </button>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-6">Upload Content</h2>
            {!selectedPlatform ? (
              <div className="space-y-4">
                <p className="text-gray-600 mb-4">Select a platform to upload your content:</p>
                {Object.entries(connectedAccounts).map(([platform, account]) => (
                  account?.connected && (
                    <button
                      key={platform}
                      onClick={() => setSelectedPlatform(platform)}
                      className="w-full flex items-center gap-3 p-4 border rounded-lg hover:bg-gray-50"
                    >
                      <div className={`text-${platform === 'youtube' ? 'red' : 'pink'}-600`}>
                        {platform === 'youtube' ? <Youtube className="w-5 h-5" /> : <Instagram className="w-5 h-5" />}
                      </div>
                      <div className="text-left">
                        <div className="font-medium">{platform === 'youtube' ? 'YouTube' : 'Instagram'}</div>
                        <div className="text-sm text-gray-500">{account.username}</div>
                      </div>
                    </button>
                  )
                ))}
                {(!connectedAccounts.youtube?.connected && !connectedAccounts.instagram?.connected) && (
                  <div className="text-center py-8">
                    <p className="text-gray-600">Please connect your accounts first</p>
                    <button
                      onClick={() => setActiveTab('accounts')}
                      className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    >
                      Go to Accounts
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium">Upload to {selectedPlatform === 'youtube' ? 'YouTube' : 'Instagram'}</h3>
                  <button
                    onClick={() => setSelectedPlatform(null)}
                    className="text-sm text-gray-600 hover:text-gray-800"
                  >
                    Change Platform
                  </button>
                </div>
                <div
                  {...getRootProps()}
                  className={`border-2 border-dashed rounded-lg p-8 text-center ${
                    isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
                  }`}
                >
                  <input {...getInputProps()} />
                  <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                  {isDragActive ? (
                    <p className="text-blue-600">Drop your video here</p>
                  ) : (
                    <div>
                      <p className="text-gray-600">Drag and drop your video here, or click to select</p>
                      <p className="text-sm text-gray-500 mt-2">Supported formats: MP4, MOV, AVI</p>
                    </div>
                  )}
                </div>
                {isUploading && (
                  <div className="mt-4">
                    <div className="flex justify-between text-sm text-gray-600 mb-1">
                      <span>Uploading...</span>
                      <span>{uploadProgress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${uploadProgress}%` }}
                      ></div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;